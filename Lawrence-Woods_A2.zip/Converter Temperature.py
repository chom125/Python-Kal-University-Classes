# -*- coding: utf-8 -*-


'''
(Convert Celsius to Fahrenheit) Write a program that reads a 
Celsius degree from the console and converts it to Fahrenheit and 
displays the result. The formula for the conversion is as follows:
fahrenheit = (9 / 5) * celsius + 32 
Here is a sample run of the program:
Enter a degree in Celsius: 43
43 Celsius is 109.4 Fahrenheit 
'''

Celsius = float(input("Enter number in Fahrenheit "))

fahrenheit = (9.0/5.0) * Celsius + 32

print("Here is a sample run of the program")

print("The conversion to Fahrenheit is: ", fahrenheit)
